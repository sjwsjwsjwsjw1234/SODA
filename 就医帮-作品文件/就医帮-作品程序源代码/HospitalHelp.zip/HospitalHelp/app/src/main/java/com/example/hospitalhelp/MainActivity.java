package com.example.hospitalhelp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        this.getSupportActionBar().hide();
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
        SearchView mSearchView = (SearchView) findViewById(R.id.searchView);
        final String[] hosp={"瑞金医院","华山医院","中山医院"};
        final int[] i = {(int) (Math.random() * 3)};
        Button btspeed = findViewById(R.id.bt_speed);
        Button btvolume = findViewById(R.id.bt_volume);
        Button bttime = findViewById(R.id.bt_time);
        Button bttech = findViewById(R.id.bt_tech);
        final AlertDialog.Builder alert1 = new AlertDialog.Builder(this);
        alert1.setTitle("排队速度");
        alert1.setPositiveButton("确定", null);
        alert1.setNeutralButton("取消", null);
        final AlertDialog.Builder alert2 = new AlertDialog.Builder(this);
        alert2.setTitle("床位余量");
        alert2.setPositiveButton("确定", null);
        alert2.setNeutralButton("取消", null);
        final AlertDialog.Builder alert3 = new AlertDialog.Builder(this);
        alert3.setTitle("路程时间");
        alert3.setPositiveButton("确定", null);
        alert3.setNeutralButton("取消", null);
        final AlertDialog.Builder alert4 = new AlertDialog.Builder(this);
        alert4.setTitle("技术水平");
        alert4.setPositiveButton("确定", null);
        alert4.setNeutralButton("取消", null);
        final AlertDialog.Builder alert5 = new AlertDialog.Builder(this);
        alert5.setTitle("搜索医院是");
        alert5.setPositiveButton("确定", null);
        alert5.setNeutralButton("取消", null);
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            // 当点击搜索按钮时触发该方法
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            // 当搜索内容改变时触发该方法
            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)){
                    int a = (int) (Math.random()*3);
                    i[0] = a;
                }
                return false;
            }
        });
        btspeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=(int) (Math.random()*100);
                alert1.setMessage(String.valueOf(a)+"分钟\n"+hosp[i[0]]);
                AlertDialog alertdialog1 = alert1.create();
                alertdialog1.show();
            }
        });
        btvolume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=(int) (Math.random()*100);
                alert2.setMessage("剩余"+String.valueOf(a)+"张床\n"+hosp[i[0]]);
                AlertDialog alertdialog2 = alert2.create();
                alertdialog2.show();
            }
        });
        bttime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a=(int) (Math.random()*100);
                alert3.setMessage(String.valueOf(a)+"分钟\n"+hosp[i[0]]);
                AlertDialog alertdialog3 = alert3.create();
                alertdialog3.show();
            }
        });
        bttech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] level = {"优","良","一般"};
                int a=(int) (Math.random()*3);
                alert4.setMessage(level[a]+"\n"+hosp[i[0]]);
                AlertDialog alertdialog4 = alert4.create();
                alertdialog4.show();
            }
        });



    }

}